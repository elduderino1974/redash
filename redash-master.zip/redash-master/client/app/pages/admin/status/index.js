import template from './status.html';

// TODO: switch to $ctrl instead of $scope.
function AdminStatusCtrl($scope, $http, $timeout, currentUser, Events) {
  Events.record('view', 'page', 'admin/status');

  const refresh = () => {
    $http.get('/status.json').success((data) => {
      $scope.workers = data.workers;
      delete data.workers;
      $scope.manager = data.manager;
      delete data.manager;
      $scope.database_metrics = data.database_metrics;
      delete data.database_metrics;
      $scope.status = data;
    });

    const timer = $timeout(refresh, 59 * 1000);

    $scope.$on('$destroy', () => {
      if (timer) {
        $timeout.cancel(timer);
      }
    });
  };

  refresh();
}

export default function init(ngModule) {
  ngModule.component('statusPage', {
    template,
    controller: AdminStatusCtrl,
  });

  return {
    '/admin/status': {
      template: '<status-page></status-page>',
      title: 'System Status',
    },
  };
}

init.init = true;
